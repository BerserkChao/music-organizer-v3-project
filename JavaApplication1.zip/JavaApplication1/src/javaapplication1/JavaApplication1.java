/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author 2188747
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        scannaTyper();
        whatIsGoingON();
        
        int num = 10;	 //where I start and I want to finish incrementing by 5 until it reaches 95
	while(num <= 95){  	//looping until <= 95
		System.out.println(num);
			num += 5;  //it will repeat printing and increment it by 5 until it gets to 95.  
      //break; //in case the the loop continues to run for no reason :P
     //actually the break will prevent the body from looping!
        }    
    }
    
    public static void scannaTyper(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Write Hello:");
        sc.nextLine();
        System.out.println("Hello Hello!");
        
      
    }
    public static void whatIsGoingON(){ 
    //THE LOGIC IN THIS METHOD IS ILLOGICAL
    //Don't bother even executing this lol because it's not doing what it's asked of :3
       String one = "Yolo";
        String two = "No";
        Scanner si = new Scanner(System.in);
        if(si.equals(one) == si.equals(two)){
            si.nextLine();
            System.out.println("You aren't even the same >:(-");
        }
        else if(si.equals(one)!= si.equals(two)){
            si.nextLine();
            System.out.println("Yes! They are not the same word!");
        }
        else{
                System.out.println("Shut up.");
            }
        }  
    }
    
